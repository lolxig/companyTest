package com.exam.test3;

/**
 * 有2个txt文件，每个文件包含2.5亿个随机的不重复正整数，每个整数占据一行，内存限制为4M，请编写程序实现如下功能：
 * <ul>
 * <li>1.	获取这两个文件中重复的正整数；</li>
 * <li>2.	将获取重复的数值里按从大到小排序的前100个数，确保不会出现内存溢出（有可能重复的正整数大小会超过4M）。</li>
 * <li>3.   返回的数值形成字符串，用英文,隔开</li>
 * </ul>
 */
public class Test3Executor {

    /**
     * 程序主入口
     *
     * @param filePath1 第一个文件路径
     * @param filePath2 第二个文件路径
     */
    public String execute(String filePath1, String filePath2) {
        return null;
    }
}
