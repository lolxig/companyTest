package com.exam.test1;

import java.util.List;

/**
 * 一个ArrayList集合A中有1000个10-999的随机正整数，请编写程序实现如下功能：
 * <ul>
 * <li>1.	将这些正整数中能够被2整除的移到集合B，能被3整除的移到集合C；</li>
 * <li>2.	启动三个并发任务，并行对集合A\B\C进行处理，获取总和小于2000的最多个数的整数子集；</li>
 * <li>3.	在三个并发任务处理完成后，将三个子集里的正整数合并为一个集合，去重后按照从大到小排序后返回。</li>
 * </ul>
 */
public class Test1Executor {
    /**
     * 程序主入口
     *
     * @param numbers 集合A
     * @return
     * @throws Exception
     */
    public List<Integer> execute(List<Integer> numbers) throws Exception {
        return null;
    }

}
